# VIXZ-ZOFC WhatsApp Bot

Bot WhatsApp berbasis [@whiskeysockets/baileys](https://github.com/WhiskeySockets/Baileys) dengan support **full proto message type WA terbaru**.

---

## ✅ Proto Message Type Support

Semua jenis pesan WA didukung oleh `messageUtils.js`:

| Type | Kategori |
|---|---|
| `conversation`, `extendedTextMessage` | Text |
| `imageMessage`, `videoMessage`, `audioMessage` | Media |
| `documentMessage`, `stickerMessage`, `ptvMessage` | Media |
| `albumMessage` | Album (multi-image/video) |
| `pollCreationMessage` v1–v5 | Poll |
| `pollUpdateMessage` | Poll Vote |
| `pollResultSnapshotMessage` / `V3` | Poll Result |
| `reactionMessage`, `encReactionMessage` | Reaction |
| `eventMessage`, `encEventResponseMessage` | Event |
| `commentMessage`, `encCommentMessage` | Comment (Channel) |
| `pinInChatMessage`, `keepInChatMessage` | Pin/Keep |
| `interactiveMessage`, `interactiveResponseMessage` | Interactive |
| `buttonsMessage`, `buttonsResponseMessage` | Buttons |
| `listMessage`, `listResponseMessage` | List |
| `templateMessage`, `templateButtonReplyMessage` | Template |
| `locationMessage`, `liveLocationMessage` | Lokasi |
| `contactMessage`, `contactsArrayMessage` | Kontak |
| `groupInviteMessage` | Grup Invite |
| `orderMessage`, `productMessage` | Produk/Order |
| `requestPaymentMessage`, `sendPaymentMessage` | Payment |
| `cancelPaymentRequestMessage`, `declinePaymentRequestMessage` | Payment |
| `paymentInviteMessage`, `invoiceMessage` | Payment |
| `scheduledCallCreationMessage`, `scheduledCallEditMessage` | Scheduled Call |
| `bcallMessage` | Group Call |
| `callLogMesssage` | Call Log |
| `newsletterAdminInviteMessage` | Channel Admin Invite |
| `newsletterFollowerInviteMessageV2` | Channel Invite |
| `stickerPackMessage` | Sticker Pack |
| `statusNotificationMessage` | Status Notification |
| `statusQuestionAnswerMessage` | Status Q&A |
| `statusQuotedMessage` | Status Reply |
| `statusStickerInteractionMessage` | Status Sticker |
| `richResponseMessage` | AI Rich Response |
| `questionResponseMessage` | Question Response |
| `placeholderMessage` | Pesan dihapus |
| `requestPhoneNumberMessage` | Request Phone Number |
| `groupMentionedMessage`, `groupStatusMentionMessage` | Group Mention |

---

## ✅ Send Utils — Semua Jenis Kirim

```js
import {
  sendMessage, sendReply, sendText,
  sendImage, sendVideo, sendAudio, sendDocument,
  sendSticker, sendPTV, sendGIF,
  sendAlbum,          // ← album multi-image/video
  sendViewOnceImage, sendViewOnceVideo,
  sendLocation, sendLiveLocation,
  sendContact, sendContacts,
  sendPoll,
  sendReaction, removeReaction,
  sendButtons, sendList, sendInteractive,
  sendEvent,          // ← event message WA
  forwardMessage, deleteMessage, editMessage,
  pinMessage, unpinMessage,
  sendWithTyping, updatePresence, markAsRead,
  followChannel, unfollowChannel, muteChannel,
  sendNewsletterReaction,
  sendTextStatus, sendImageStatus, sendVideoStatus,
  sendMention, sendMentionReply,
  sendGroupInvite, requestPhoneNumber,
  broadcastText,
} from './src/utils/sendUtils.js'
```

---

## 🚀 Setup

```bash
npm install
node index.js
```

Masukkan nomor WA format `628xxx` saat diminta, lalu masukkan pairing code di WA → Perangkat Tertaut.

---

## 📁 Struktur Project

```
vixzzofc-wa/
├── index.js
├── package.json
├── src/
│   ├── config.js
│   ├── connection.js
│   ├── logger.js
│   ├── handler/
│   │   ├── messageHandler.js     ← upgrade: handle semua type WA terbaru
│   │   ├── commandRouter.js
│   │   └── commands/
│   │       ├── index.js
│   │       ├── ping.js
│   │       ├── menu.js
│   │       ├── info.js
│   │       ├── poll.js           ← baru
│   │       ├── react.js          ← baru
│   │       └── id.js             ← baru
│   └── utils/
│       ├── messageUtils.js       ← upgrade: full proto type support
│       ├── sendUtils.js          ← upgrade: semua jenis send
│       └── groupUtils.js         ← upgrade: full group management
└── auth_info_baileys/
```

---

## 📌 Custom Type Hook

Tangkap pesan type tertentu dengan `onMessageType`:

```js
import { onMessageType } from './src/handler/messageHandler.js'

// Handle setiap reaction yang masuk
onMessageType('reactionMessage', async (sock, msg, rawMsg) => {
  console.log(`${msg.sender} react ${msg.reaction.emoji} ke ${msg.reaction.key?.id}`)
})

// Handle event message
onMessageType('eventMessage', async (sock, msg, rawMsg) => {
  console.log('Event diterima:', msg.event)
})

// Handle poll vote
onMessageType('pollUpdateMessage', async (sock, msg, rawMsg) => {
  console.log('Poll vote diterima:', msg.pollUpdate)
})
```

---

by vixzzofc
