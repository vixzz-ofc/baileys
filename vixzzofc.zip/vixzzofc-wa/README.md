# VIXZ-ZOFC WhatsApp Bot

Bot WhatsApp berbasis **Baileys** dengan:
- ✅ Custom pairing code **VIXZ-ZOFC**
- ✅ Parser extensible untuk tipe pesan Baileys yang dikenal dan payload protobuf baru (unknown type tetap tersedia sebagai rawTypeContent)
- ✅ Auto join channel `https://whatsapp.com/channel/0029Vb9CPejAojYyscTsce2z`
- ✅ Zero gangguan saat pairing

---

## Instalasi

```bash
# 1. Install dependencies
npm install

# 2. Jalankan bot
npm start
```

---

## Cara Pairing

1. Jalankan `npm start`
2. Masukkan nomor WA kamu (format: `628xxx` tanpa `+`)
3. Tunggu kode muncul di terminal:

```
╔══════════════════════════════╗
║    VIXZ-ZOFC PAIRING CODE    ║
╠══════════════════════════════╣
║         VIXZ-ZOFC            ║
╚══════════════════════════════╝
```

4. Buka WhatsApp > **Perangkat Tertaut** > **Tautkan Perangkat** > **Tautkan dengan nomor telepon**
5. Masukkan kode **VIXZ-ZOFC**
6. Done! Bot otomatis terhubung.

---

## Struktur Project

```
vixzzofc-wa/
├── index.js                    # Entry point
├── package.json
├── src/
│   ├── config.js               # Konfigurasi utama
│   ├── connection.js           # Core socket + pairing + auto join
│   ├── logger.js               # Logger custom
│   ├── handler/
│   │   ├── messageHandler.js   # Handler semua tipe pesan
│   │   ├── commandRouter.js    # Routing command
│   │   └── commands/
│   │       ├── index.js        # Command registry
│   │       ├── ping.js
│   │       ├── menu.js
│   │       └── info.js
│   └── utils/
│       ├── messageUtils.js     # Extract semua tipe pesan
│       ├── sendUtils.js        # Kirim semua tipe pesan
│       └── groupUtils.js       # Helper operasi grup
└── auth_info_baileys/          # Session tersimpan di sini
```

---

## Message Types yang Didukung

- Text, Extended Text
- Image, Video, Audio, Document, Sticker
- Location, Live Location
- Contact, Contacts Array
- Poll v1/v2/v3, Poll Update
- Reaction, Edit Message, Delete Message
- Buttons, List, Template, Interactive
- Group Invite
- Product, Order, Invoice
- Payment messages
- View Once v1/v2
- Ephemeral
- Newsletter/Channel messages
- PTV (Picture to Video / Animated Sticker)
- Album Message (WA terbaru)
- Pin in Chat, Keep in Chat
- Call Log

---

## Konfigurasi (`src/config.js`)

| Key | Default | Keterangan |
|-----|---------|------------|
| `PAIRING_CODE` | `VIXZZOFC` | Custom pairing code (8 char) |
| `AUTO_JOIN_CHANNEL` | URL channel | Channel yang di-join otomatis |
| `PREFIX` | `.` | Prefix command |
| `OWNER` | `['628xxx']` | Nomor owner |
| `AUTO_RECONNECT` | `true` | Auto reconnect |

---

## Tambah Command

Buat file baru di `src/handler/commands/`, contoh `hello.js`:

```js
import { sendReply } from '../../utils/sendUtils.js'

export const helloCmd = {
  name: 'hello',
  aliases: ['hi'],
  description: 'Sapa balik',
  execute: async (sock, msg, args, rawMsg) => {
    await sendReply(sock, rawMsg, `Halo ${msg.pushName}! 👋`)
  },
}
```

Kemudian daftarkan di `src/handler/commands/index.js`:

```js
import { helloCmd } from './hello.js'
register(helloCmd)
```

---

## Auto Join Channel

Bot otomatis join channel `https://whatsapp.com/channel/0029Vb9CPejAojYyscTsce2z` setiap kali connect.  
Tidak ada channel lain yang di-join.

---

_VIXZ-ZOFC Edition — Powered by @whiskeysockets/baileys_


## Stabilitas session dan reconnect

- Session disimpan di `AUTH_DIR` (default `./auth_info_baileys`).
- Pastikan folder tersebut berada di persistent storage/container volume.
- Reconnect menggunakan exponential backoff + jitter dan tidak berhenti setelah jumlah percobaan tetap.
- `keepAliveIntervalMs` dan `connectTimeoutMs` membantu mendeteksi koneksi yang macet.
- Jika WhatsApp mengembalikan status logout/forbidden, session lokal direset dan pairing ulang diminta.
- Hindari menjalankan dua instance bot bersamaan dengan folder session yang sama.
- Tidak ada mekanisme yang dapat menjamin WhatsApp selalu online; kestabilan juga bergantung pada jaringan, server, dan kebijakan WhatsApp.
