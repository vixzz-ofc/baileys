import { CONFIG } from '../config.js'
import { extractMessageContent } from '../utils/messageUtils.js'
import { commandRouter } from './commandRouter.js'

// Do not hard-code an allow-list here: WhatsApp adds protobuf message types
// over time. Every incoming payload is normalized and its original type/raw
// content remains available to handlers.
export async function messageHandler(sock, upsert) {
  const { messages = [], type } = upsert || {}

  // "notify" is the live incoming-message stream. "append" is commonly
  // history/sync; don't execute old commands from it.
  if (type !== 'notify') return

  for (const rawMsg of messages) {
    try {
      if (!rawMsg?.message || rawMsg.key?.fromMe) continue

      const msg = await extractMessageContent(rawMsg, sock)
      if (!msg) continue

      // Internal protocol payloads are exposed by the parser but are not
      // user commands.
      if (msg.type === 'protocolMessage' || msg.type === 'senderKeyDistributionMessage') {
        continue
      }

      if (typeof msg.text === 'string' && msg.text.startsWith(CONFIG.PREFIX)) {
        await commandRouter(sock, msg, rawMsg)
      }
    } catch (error) {
      // Keep one malformed/unsupported message from stopping the queue.
      console.error('[MESSAGE_HANDLER]', error?.message || error)
    }
  }
}
