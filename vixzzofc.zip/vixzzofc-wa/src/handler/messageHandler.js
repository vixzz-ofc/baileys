import { CONFIG } from '../config.js'
import { extractMessageContent, SKIP_TYPES } from '../utils/messageUtils.js'
import { commandRouter } from './commandRouter.js'

// ─────────────────────────────────────────────────────────────────────────────
//  MESSAGE TYPE HOOKS
//  Daftarkan handler untuk type tertentu di sini.
//  Format: { type: string, handler: async (sock, msg, rawMsg) => void }
//
//  Contoh custom hook:
//  typeHooks.set('reactionMessage', async (sock, msg, rawMsg) => { ... })
// ─────────────────────────────────────────────────────────────────────────────
export const typeHooks = new Map()

// ─────────────────────────────────────────────────────────────────────────────
//  MAIN MESSAGE HANDLER
// ─────────────────────────────────────────────────────────────────────────────
export async function messageHandler(sock, upsert) {
  const { messages = [], type } = upsert || {}

  // "notify" = pesan masuk baru secara realtime
  // "append" = history sync — skip agar command lama tidak jalan ulang
  if (type !== 'notify') return

  for (const rawMsg of messages) {
    try {
      // Skip jika tidak ada content atau pesan dari diri sendiri
      if (!rawMsg?.message || rawMsg.key?.fromMe) continue

      const msg = await extractMessageContent(rawMsg, sock)
      if (!msg) continue

      // ── Skip internal protocol messages ──────────────────────────────────
      if (SKIP_TYPES.has(msg.type)) continue

      // ── Dispatch ke type hook jika ada ───────────────────────────────────
      const hook = typeHooks.get(msg.type)
      if (hook) {
        try {
          await hook(sock, msg, rawMsg)
        } catch (hookErr) {
          console.error(`[TYPE_HOOK:${msg.type}]`, hookErr?.message || hookErr)
        }
      }

      // ── Poll update handler ──────────────────────────────────────────────
      if (msg.type === 'pollUpdateMessage') {
        // Poll vote diterima — bisa ditambah logic custom di sini
        continue
      }

      // ── Reaction message — skip dari command routing ─────────────────────
      if (msg.type === 'reactionMessage') continue

      // ── Pin/unpin — informational only ───────────────────────────────────
      if (msg.type === 'pinInChatMessage') continue

      // ── Keep in chat ─────────────────────────────────────────────────────
      if (msg.type === 'keepInChatMessage') continue

      // ── Event/album/payment/scheduled call — bisa di-handle custom ───────
      if (
        msg.type === 'eventMessage' ||
        msg.type === 'albumMessage' ||
        msg.type === 'scheduledCallCreationMessage' ||
        msg.type === 'scheduledCallEditMessage'
      ) {
        // Tidak dijadikan command, tapi type hook bisa menangkap ini
        continue
      }

      // ── Newsletter/channel messages ───────────────────────────────────────
      if (msg.isChannel) {
        // Pesan dari channel — biasanya tidak perlu diproses sebagai command
        continue
      }

      // ── Status/story ─────────────────────────────────────────────────────
      if (msg.isStatus) continue

      // ── Command routing ──────────────────────────────────────────────────
      if (typeof msg.text === 'string' && msg.text.startsWith(CONFIG.PREFIX)) {
        await commandRouter(sock, msg, rawMsg)
      }

    } catch (error) {
      console.error('[MESSAGE_HANDLER]', error?.message || error)
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  HELPER: Register type hook dari luar
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Daftarkan custom handler untuk message type tertentu.
 * @param {string} type — nama type, contoh: 'reactionMessage', 'eventMessage'
 * @param {Function} handler — async (sock, msg, rawMsg) => void
 */
export function onMessageType(type, handler) {
  typeHooks.set(type, handler)
}
