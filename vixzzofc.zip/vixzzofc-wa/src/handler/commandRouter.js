import { CONFIG } from '../config.js'
import { sendReply } from '../utils/sendUtils.js'
import { commands } from './commands/index.js'

// ─── command router ───────────────────────────────────────────────────────────
export async function commandRouter(sock, msg, rawMsg) {
  try {
    const prefixLength = CONFIG.PREFIX.length
    const body = msg.text.slice(prefixLength).trim()
    const args = body.split(/\s+/)
    const commandName = args[0]?.toLowerCase()
    const params = args.slice(1)

    if (!commandName) return

    const cmd = commands.get(commandName)

    if (!cmd) {
      // Tidak kirim error ke user — command tidak dikenal, skip
      return
    }

    await cmd.execute(sock, msg, params, rawMsg)
  } catch (err) {
    try {
      await sendReply(sock, rawMsg, `❌ Error: ${err.message}`)
    } catch {}
  }
}
