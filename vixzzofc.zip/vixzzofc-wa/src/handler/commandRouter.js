import { CONFIG } from '../config.js'
import { sendReply } from '../utils/sendUtils.js'
import { commands } from './commands/index.js'

// ─── command router ───────────────────────────────────────────────────────────
export async function commandRouter(sock, msg, rawMsg) {
  try {
    const body = msg.text.slice(CONFIG.PREFIX.length).trim()
    const args = body.split(/\s+/)
    const commandName = args[0]?.toLowerCase()
    const params = args.slice(1)

    if (!commandName) return

    // cari command
    const cmd = commands.get(commandName)

    if (!cmd) {
      // command tidak ditemukan, skip (tidak kirim error)
      return
    }

    await cmd.execute(sock, msg, params, rawMsg)
  } catch (err) {
    try { await sendReply(sock, msg.raw, `❌ Error: ${err.message}`) } catch {}
  }
}
