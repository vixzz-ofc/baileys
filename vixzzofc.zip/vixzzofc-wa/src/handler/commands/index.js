import { pingCmd } from './ping.js'
import { menuCmd } from './menu.js'
import { infoCmd } from './info.js'
import { pollCmd } from './poll.js'
import { reactCmd } from './react.js'
import { idCmd } from './id.js'

// ─── command registry ─────────────────────────────────────────────────────────
export const commands = new Map()

const register = (cmd) => {
  commands.set(cmd.name, cmd)
  if (cmd.aliases) {
    cmd.aliases.forEach(alias => commands.set(alias, cmd))
  }
}

register(pingCmd)
register(menuCmd)
register(infoCmd)
register(pollCmd)
register(reactCmd)
register(idCmd)
