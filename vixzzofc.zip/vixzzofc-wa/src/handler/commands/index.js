import { pingCmd } from './ping.js'
import { menuCmd } from './menu.js'
import { infoCmd } from './info.js'

// ─── command registry ─────────────────────────────────────────────────────────
export const commands = new Map()

// daftarkan semua command
const register = (cmd) => {
  commands.set(cmd.name, cmd)
  if (cmd.aliases) {
    cmd.aliases.forEach((alias) => commands.set(alias, cmd))
  }
}

register(pingCmd)
register(menuCmd)
register(infoCmd)
