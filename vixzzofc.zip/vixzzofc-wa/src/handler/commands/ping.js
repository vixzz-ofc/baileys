import { sendReply } from '../../utils/sendUtils.js'

export const pingCmd = {
  name: 'ping',
  aliases: ['p'],
  description: 'Cek apakah bot aktif',
  execute: async (sock, msg, args, rawMsg) => {
    const start = Date.now()
    await sendReply(sock, rawMsg, '🏓 Pong!')
    const end = Date.now()
    await sendReply(sock, rawMsg, `⚡ Latency: ${end - start}ms`)
  },
}
