import { sendReaction, sendReply } from '../../utils/sendUtils.js'

export const reactCmd = {
  name: 'react',
  aliases: ['r'],
  description: 'React ke pesan yang di-quote — .react 👍',
  execute: async (sock, msg, args, rawMsg) => {
    const emoji = args[0] || '👍'

    // Cek apakah ada quoted message
    const quotedKey = rawMsg.message?.extendedTextMessage?.contextInfo?.stanzaId
    const quotedParticipant = rawMsg.message?.extendedTextMessage?.contextInfo?.participant
      || rawMsg.message?.extendedTextMessage?.contextInfo?.remoteJid

    if (!quotedKey) {
      // React ke pesan sendiri sebagai demo
      await sendReaction(sock, rawMsg.key.remoteJid, rawMsg.key, emoji)
      return
    }

    const targetKey = {
      remoteJid: rawMsg.key.remoteJid,
      id: quotedKey,
      fromMe: false,
      participant: quotedParticipant,
    }

    await sendReaction(sock, rawMsg.key.remoteJid, targetKey, emoji)
  },
}
