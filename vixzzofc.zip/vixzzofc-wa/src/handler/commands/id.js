import { sendReply } from '../../utils/sendUtils.js'

export const idCmd = {
  name: 'id',
  aliases: ['cid', 'chatid'],
  description: 'Lihat ID chat/grup saat ini',
  execute: async (sock, msg, args, rawMsg) => {
    const jid = rawMsg.key.remoteJid
    const sender = msg.senderNumber
    const isGroup = msg.isGroup
    let text = `*📌 Chat Info*\n\n`
    text += `*JID:* ${jid}\n`
    text += `*Sender:* ${sender}\n`
    text += `*Type:* ${isGroup ? 'Grup' : msg.isChannel ? 'Channel' : 'DM'}\n`
    text += `*Bot JID:* ${sock.user?.id || '-'}`
    await sendReply(sock, rawMsg, text)
  },
}
