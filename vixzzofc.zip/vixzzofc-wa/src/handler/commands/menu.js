import { sendReply } from '../../utils/sendUtils.js'
import { CONFIG } from '../../config.js'

export const menuCmd = {
  name: 'menu',
  aliases: ['help', 'h'],
  description: 'Tampilkan daftar command',
  execute: async (sock, msg, args, rawMsg) => {
    const text = `╔══════════════════════╗
║   *VIXZZOFC BOT*    ║
╚══════════════════════╝

*📌 General*
${CONFIG.PREFIX}ping — Cek bot aktif
${CONFIG.PREFIX}menu — Tampilkan menu
${CONFIG.PREFIX}info — Info bot

*Prefix:* ${CONFIG.PREFIX}
*Bot:* ${CONFIG.BOT_NAME}`

    await sendReply(sock, rawMsg, text)
  },
}
