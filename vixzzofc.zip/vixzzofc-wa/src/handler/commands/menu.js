import { sendReply } from '../../utils/sendUtils.js'
import { CONFIG } from '../../config.js'

export const menuCmd = {
  name: 'menu',
  aliases: ['help', 'h'],
  description: 'Tampilkan daftar command',
  execute: async (sock, msg, args, rawMsg) => {
    const p = CONFIG.PREFIX
    const text = `╔══════════════════════╗
║   *VIXZZOFC BOT*    ║
╚══════════════════════╝

*📌 General*
${p}ping — Cek bot aktif
${p}menu — Tampilkan menu
${p}info — Info bot

*📷 Media*
${p}sticker — Buat sticker dari gambar
${p}toimg — Convert sticker ke gambar

*📊 Interaktif*
${p}poll [pertanyaan] | [opsi1] | [opsi2] — Buat poll

*🔧 Utilitas*
${p}react [emoji] — React ke pesan
${p}del — Hapus pesan bot
${p}id — Lihat ID grup/chat

*Prefix:* ${p}
*Bot:* ${CONFIG.BOT_NAME}`

    await sendReply(sock, rawMsg, text)
  },
}
