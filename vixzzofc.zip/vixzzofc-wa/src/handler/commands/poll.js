import { sendPoll, sendReply } from '../../utils/sendUtils.js'

export const pollCmd = {
  name: 'poll',
  aliases: ['vote'],
  description: 'Buat poll — .poll pertanyaan | opsi1 | opsi2',
  execute: async (sock, msg, args, rawMsg) => {
    const fullText = msg.text.slice(msg.text.indexOf(args[0] === '' ? '' : args.join(' ').length)).trim()
    const body = msg.raw?.message?.extendedTextMessage?.text
      || msg.raw?.message?.conversation
      || msg.text || ''

    const parts = body
      .replace(/^[^\s]+\s*/, '') // hapus prefix+command
      .split('|')
      .map(s => s.trim())
      .filter(Boolean)

    if (parts.length < 2) {
      return await sendReply(sock, rawMsg, '❌ Format salah!\n\nContoh: .poll Makan siang? | Nasi goreng | Mie ayam | Soto')
    }

    const question = parts[0]
    const options = parts.slice(1)

    if (options.length < 2) {
      return await sendReply(sock, rawMsg, '❌ Minimal 2 opsi diperlukan')
    }
    if (options.length > 12) {
      return await sendReply(sock, rawMsg, '❌ Maksimal 12 opsi')
    }

    await sendPoll(sock, rawMsg.key.remoteJid, question, options, 1, { quoted: rawMsg })
  },
}
