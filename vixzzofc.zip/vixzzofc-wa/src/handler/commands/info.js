import { sendReply } from '../../utils/sendUtils.js'
import { CONFIG } from '../../config.js'

export const infoCmd = {
  name: 'info',
  aliases: ['about'],
  description: 'Info tentang bot',
  execute: async (sock, msg, args, rawMsg) => {
    const me = sock.user
    const text = `*🤖 INFO BOT*

*Nama:* ${CONFIG.BOT_NAME}
*JID:* ${me?.id || '-'}
*Prefix:* ${CONFIG.PREFIX}
*Node:* ${process.version}
*Platform:* ${process.platform}
*Uptime:* ${Math.floor(process.uptime() / 60)}m ${Math.floor(process.uptime() % 60)}s

_Powered by Baileys vixzzofc`

    await sendReply(sock, rawMsg, text)
  },
}
