import { sendReply } from '../../utils/sendUtils.js'
import { CONFIG } from '../../config.js'

export const infoCmd = {
  name: 'info',
  aliases: ['about'],
  description: 'Info tentang bot',
  execute: async (sock, msg, args, rawMsg) => {
    const me = sock.user
    const uptime = process.uptime()
    const hours = Math.floor(uptime / 3600)
    const minutes = Math.floor((uptime % 3600) / 60)
    const seconds = Math.floor(uptime % 60)

    const text = `*🤖 INFO BOT*

*Nama:* ${CONFIG.BOT_NAME}
*JID:* ${me?.id || '-'}
*Prefix:* ${CONFIG.PREFIX}
*Node.js:* ${process.version}
*Platform:* ${process.platform}
*Arch:* ${process.arch}
*Uptime:* ${hours}h ${minutes}m ${seconds}s
*Mem Usage:* ${Math.round(process.memoryUsage().rss / 1024 / 1024)}MB

_Powered by @whiskeysockets/baileys_`

    await sendReply(sock, rawMsg, text)
  },
}
