import {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  isJidBroadcast,
  proto,
  makeInMemoryStore,
  Browsers
} from '@whiskeysockets/baileys'
import { Boom } from '@hapi/boom'
import pino from 'pino'
import fs from 'fs'
import path from 'path'
import readline from 'readline'
import NodeCache from 'node-cache'
import { CONFIG } from './config.js'
import { messageHandler } from './handler/messageHandler.js'

const logger = pino({ level: CONFIG.LOG_LEVEL || 'silent' })
const keyStoreLogger = pino({ level: 'silent' })
const groupCache = new NodeCache({ stdTTL: 300, checkperiod: 60 })
const store = makeInMemoryStore({ logger: pino({ level: 'silent' }) })

const question = (text) => new Promise((resolve) => {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  rl.question(text, (answer) => {
    rl.close()
    resolve(answer.trim())
  })
})

async function resolveChannelJid(sock, channelUrl) {
  try {
    const result = await sock.newsletterMetadata('invite', channelUrl)
    if (result?.id) return result.id
  } catch {}
  try {
    const inviteCode = channelUrl.split('/channel/')[1]
    if (inviteCode) {
      const result = await sock.newsletterMetadata('invite', inviteCode)
      if (result?.id) return result.id
    }
  } catch {}
  return null
}

async function autoJoinChannels(sock) {
  const channels = CONFIG.AUTO_JOIN_CHANNELS
  if (!Array.isArray(channels) || channels.length === 0) return

  // Tunggu sebentar supaya koneksi stabil dulu
  await new Promise(resolve => setTimeout(resolve, 3000))

  for (const url of channels) {
    try {
      const jid = await resolveChannelJid(sock, url)
      if (jid) {
        await sock.newsletterFollow(jid)
        logger.info({ jid, url }, 'Auto-follow channel berhasil')
      } else {
        logger.warn({ url }, 'Auto-follow channel: JID tidak ditemukan')
      }
      // Jeda antar follow supaya tidak rate-limit
      await new Promise(resolve => setTimeout(resolve, 1500))
    } catch (error) {
      logger.warn({ err: error, url }, 'Auto-follow channel gagal; koneksi tetap berjalan')
    }
  }
}

let currentSocket = null
let reconnectTimer = null
let reconnectAttempts = 0
let starting = false
let stopped = false
let pairingInProgress = false

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

function clearReconnectTimer() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }
}

function reconnectDelay() {
  const base = Math.max(1000, CONFIG.RECONNECT_DELAY || 3000)
  const cap = Math.max(base, CONFIG.MAX_RECONNECT_DELAY || 60000)
  const exponential = Math.min(cap, base * (2 ** Math.min(reconnectAttempts, 6)))
  // Small jitter prevents synchronized reconnect storms after a provider outage.
  return Math.round(exponential * (0.85 + Math.random() * 0.3))
}

function scheduleReconnect(reason = 'connection closed', immediate = false) {
  if (stopped || reconnectTimer) return
  reconnectAttempts += 1
  const delay = immediate ? 500 : reconnectDelay()
  logger.warn({ attempt: reconnectAttempts, delay, reason }, 'WhatsApp reconnect dijadwalkan')
  reconnectTimer = setTimeout(async () => {
    reconnectTimer = null
    try {
      await connectToWhatsApp()
    } catch (error) {
      logger.error({ err: error }, 'Gagal membuat koneksi ulang')
      scheduleReconnect('socket initialization failed')
    }
  }, delay)
  reconnectTimer.unref?.()
}

function getDisconnectCode(error) {
  try {
    return new Boom(error).output?.statusCode
  } catch {
    return error?.output?.statusCode
  }
}

async function requestPairingIfNeeded(sock, state) {
  if (state.creds.registered || pairingInProgress) return
  pairingInProgress = true
  try {
    let phoneNumber = await question(
      'Masukkan nomor WhatsApp (format 628xxx, tanpa + dan spasi): '
    )
    phoneNumber = phoneNumber.replace(/\D/g, '')
    if (phoneNumber.length < 8) {
      logger.error('Nomor tidak valid. Restart bot lalu masukkan nomor yang benar.')
      return
    }

    await sleep(1200)
    const code = await sock.requestPairingCode(phoneNumber, CONFIG.PAIRING_CODE)
    const displayCode = code?.match(/.{1,4}/g)?.join('-') || code
    console.log(`\nPAIRING CODE: ${displayCode}\n`)
    console.log('Masukkan kode tersebut melalui WhatsApp > Perangkat tertaut > Tautkan dengan nomor telepon.')
  } catch (error) {
    logger.error({ err: error }, 'Gagal meminta pairing code')
    // A transient pairing request failure should not kill the process.
    scheduleReconnect('pairing code request failed')
  } finally {
    pairingInProgress = false
  }
}

export async function connectToWhatsApp() {
  if (stopped || starting) return currentSocket
  if (currentSocket && currentSocket.ws?.readyState === 1) return currentSocket

  starting = true
  clearReconnectTimer()

  try {
    fs.mkdirSync(path.resolve(CONFIG.AUTH_DIR), { recursive: true })
    const { state, saveCreds } = await useMultiFileAuthState(CONFIG.AUTH_DIR)

    let version
    try {
      const latest = await fetchLatestBaileysVersion()
      version = latest?.version
    } catch (error) {
      logger.warn({ err: error }, 'Tidak dapat mengambil versi WhatsApp terbaru; memakai default Baileys')
    }

    const sock = makeWASocket({
      ...(version ? { version } : {}),
      logger,
      printQRInTerminal: false,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, keyStoreLogger),
      },
      browser: CONFIG.BROWSER
        ? CONFIG.BROWSER
        : Browsers.ubuntu('Chrome'),
      generateHighQualityLinkPreview: true,
      syncFullHistory: false,
      markOnlineOnConnect: CONFIG.MARK_ONLINE === true,
      keepAliveIntervalMs: CONFIG.KEEP_ALIVE_INTERVAL_MS || 25000,
      connectTimeoutMs: CONFIG.CONNECT_TIMEOUT_MS || 60000,
      defaultQueryTimeoutMs: CONFIG.DEFAULT_QUERY_TIMEOUT_MS || 60000,
      retryRequestDelayMs: 1000,
      maxMsgRetryCount: 5,
      getMessage: async (key) => {
        const msg = await store.loadMessage(key.remoteJid, key.id)
        return msg?.message || proto.Message.fromObject({})
      },
      cachedGroupMetadata: async (jid) => groupCache.get(jid) || null,
      shouldIgnoreJid: (jid) => isJidBroadcast(jid),
    })

    currentSocket = sock
    store.bind(sock.ev)

    sock.ev.on('creds.update', async () => {
      try {
        await saveCreds()
      } catch (error) {
        logger.error({ err: error }, 'Gagal menyimpan session WhatsApp')
      }
    })

    sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
      if (sock !== currentSocket) return

      if (connection === 'connecting') {
        logger.info('Menghubungkan ke WhatsApp...')
      }

      if (connection === 'open') {
        reconnectAttempts = 0
        logger.info('WhatsApp terhubung; session aktif')
        autoJoinChannels(sock)
      }

      if (connection === 'close') {
        const statusCode = getDisconnectCode(lastDisconnect?.error)
        currentSocket = null

        const loggedOut = statusCode === DisconnectReason.loggedOut
        const forbidden = statusCode === DisconnectReason.forbidden

        try { sock.ws?.close() } catch {}

        if (loggedOut || forbidden) {
          logger.error('Session WhatsApp tidak valid / logout. Session lokal akan direset agar pairing ulang dapat dilakukan.')
          try {
            fs.rmSync(path.resolve(CONFIG.AUTH_DIR), { recursive: true, force: true })
          } catch (error) {
            logger.error({ err: error }, 'Gagal mereset session lokal')
          }
          scheduleReconnect('session requires re-pairing', true)
          return
        }

        if (CONFIG.AUTO_RECONNECT !== false) {
          scheduleReconnect(`disconnect code ${statusCode ?? 'unknown'}`)
        } else {
          logger.error('AUTO_RECONNECT nonaktif; bot tidak melakukan reconnect.')
        }
      }
    })

    sock.ev.on('messages.upsert', async upsert => {
      try {
        await messageHandler(sock, upsert)
      } catch (error) {
        logger.error({ err: error }, 'Message handler error')
      }
    })

    sock.ev.on('groups.update', async updates => {
      for (const update of updates) {
        if (!update.id) continue
        try {
          const metadata = await sock.groupMetadata(update.id)
          groupCache.set(update.id, metadata)
        } catch (error) {
          logger.debug({ err: error, group: update.id }, 'Group metadata refresh gagal')
        }
      }
    })

    sock.ev.on('call', async calls => {
      for (const call of calls) {
        if (call.status === 'offer') {
          try { await sock.rejectCall(call.id, call.from) } catch {}
        }
      }
    })

    await requestPairingIfNeeded(sock, state)
    return sock
  } catch (error) {
    logger.error({ err: error }, 'Inisialisasi WhatsApp gagal')
    currentSocket = null
    scheduleReconnect('initialization error')
    throw error
  } finally {
    starting = false
  }
}

export async function disconnectWhatsApp() {
  stopped = true
  clearReconnectTimer()
  const sock = currentSocket
  currentSocket = null
  try { sock?.end(new Error('Bot stopped by operator')) } catch {}
}

export function getWhatsAppSocket() {
  return currentSocket
}
