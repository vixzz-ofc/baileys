// ============================================
//   VIXZ-ZOFC WhatsApp Bot Configuration
// ============================================

export const CONFIG = {
  // Pairing code custom — 8 karakter alphanumerik
  // tampil sebagai VIXZ-ZOFC di WhatsApp
  PAIRING_CODE: 'VIXZZOFC',

  // Auto join channel ini setelah connect
  AUTO_JOIN_CHANNEL: 'https://whatsapp.com/channel/0029Vb9CPejAojYyscTsce2z',

  // Nama bot
  BOT_NAME: 'VIXZ-ZOFC Bot',

  // Folder auth session
  AUTH_DIR: './auth_info_baileys',

  // Reconnect otomatis
  AUTO_RECONNECT: true,

  // Max reconnect attempts
  MAX_RECONNECT: 0, // 0 = retry terus sampai server dihentikan

  // Delay reconnect ms
  RECONNECT_DELAY: 3000,
  MAX_RECONNECT_DELAY: 60000,
  KEEP_ALIVE_INTERVAL_MS: 25000,
  CONNECT_TIMEOUT_MS: 60000,
  DEFAULT_QUERY_TIMEOUT_MS: 60000,

  // Prefix command
  PREFIX: '.',

  // Owner number (isi nomor kamu, format: 628xxx)
  OWNER: ['6282017260421'],

  // Log level: 'silent' | 'info' | 'debug' | 'warn' | 'error' | 'trace'
  LOG_LEVEL: 'silent',

  // Browser identity supaya stabil
  BROWSER: ['VIXZ-ZOFC', 'Chrome', '120.0.0'],

  // Mark messages as read otomatis
  MARK_ONLINE: true,
}
