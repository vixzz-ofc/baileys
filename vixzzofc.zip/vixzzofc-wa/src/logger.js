import chalk from 'chalk'

const time = () => new Date().toLocaleTimeString('id-ID', { hour12: false })

export const logger = {
  info: (...args) => console.log(chalk.cyan(`[${time()}] [INFO]`), ...args),
  success: (...args) => console.log(chalk.green(`[${time()}] [✓]`), ...args),
  warn: (...args) => console.log(chalk.yellow(`[${time()}] [WARN]`), ...args),
  error: (...args) => console.log(chalk.red(`[${time()}] [ERR]`), ...args),
  debug: (...args) => console.log(chalk.gray(`[${time()}] [DBG]`), ...args),
  banner: () => {
    console.log(chalk.bold.magenta(`
  ██╗   ██╗██╗██╗  ██╗███████╗ ███████╗
  ██║   ██║██║╚██╗██╔╝╚══███╔╝╚══███╔╝
  ██║   ██║██║ ╚███╔╝   ███╔╝    ███╔╝
  ╚██╗ ██╔╝██║ ██╔██╗  ███╔╝    ███╔╝
   ╚████╔╝ ██║██╔╝ ██╗███████╗╗███████╗
    ╚═══╝  ╚═╝╚═╝  ╚═╝╚══════╝  ╚══════╝
`))
    console.log('')
  }
}
