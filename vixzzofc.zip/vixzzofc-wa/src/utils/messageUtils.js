import {
  getContentType,
  downloadMediaMessage,
  extractMessageContent as baileysExtract,
} from '@whiskeysockets/baileys'

/**
 * Unwrap standard WhatsApp message wrappers while preserving the original
 * message on `raw`. Unknown/new message types remain available as `content`.
 */
function unwrapMessage(message) {
  let current = message
  const wrappers = new Set([
    'ephemeralMessage',
    'viewOnceMessage',
    'viewOnceMessageV2',
    'viewOnceMessageV2Extension',
    'documentWithCaptionMessage',
    'deviceSentMessage',
    'editedMessage',
  ])

  for (let i = 0; i < 12 && current && typeof current === 'object'; i++) {
    const type = getContentType(current)
    if (!type || !wrappers.has(type)) break
    const wrapped = current[type]
    const next = wrapped?.message || wrapped?.editedMessage?.message
    if (!next || next === current) break
    current = next
  }

  // Baileys' helper covers wrapper variants known to the installed version.
  try {
    const extracted = baileysExtract(message)
    if (extracted && getContentType(extracted)) current = extracted
  } catch {}

  return current || message
}

function extractText(inner, type, content) {
  if (!inner || !type) return ''

  if (type === 'conversation') return inner.conversation || ''

  const directText = [
    content?.text,
    content?.caption,
    content?.selectedButtonId,
    content?.selectedDisplayText,
    content?.selectedId,
    content?.singleSelectReply?.selectedRowId,
    content?.nativeFlowResponseMessage?.name,
    content?.name,
    content?.displayName,
    content?.body?.text,
  ].find(value => typeof value === 'string' && value.length)

  if (directText) return directText

  if (type === 'interactiveResponseMessage') {
    const params = content?.nativeFlowResponseMessage?.paramsJson
    if (typeof params === 'string') {
      try {
        const parsed = JSON.parse(params)
        return parsed?.id || parsed?.title || parsed?.name || ''
      } catch {}
    }
  }

  if (type === 'groupInviteMessage') {
    return content?.caption || `Undangan Grup: ${content?.groupName || ''}`
  }
  if (type === 'orderMessage') return `Order: ${content?.orderId || ''}`
  if (type === 'productMessage') return content?.product?.productImage?.caption || ''
  if (type === 'contactsArrayMessage') {
    return content?.contacts?.map(c => c.displayName).filter(Boolean).join(', ') || ''
  }
  if (type === 'pollCreationMessage' || /^pollCreationMessageV\d+$/.test(type)) {
    return content?.name || ''
  }
  if (type === 'reactionMessage') return content?.text || ''
  if (type === 'pinInChatMessage') return '[Pin Message]'
  if (type === 'keepInChatMessage') return '[Keep in Chat]'
  if (type === 'callLogMessage') return '[Call Log]'

  // Retain readable text for newly introduced protobuf message types.
  return ''
}

function extractQuoted(content) {
  const ctx = content?.contextInfo
  if (!ctx?.quotedMessage) return null

  const quotedType = getContentType(ctx.quotedMessage)
  const quotedContent = quotedType ? ctx.quotedMessage[quotedType] : null

  return {
    type: quotedType || 'unknown',
    sender: ctx.participant || ctx.remoteJid || '',
    stanzaId: ctx.stanzaId || '',
    text: extractText(ctx.quotedMessage, quotedType, quotedContent),
    content: quotedContent,
    raw: ctx.quotedMessage,
  }
}

function extractMediaInfo(type, content) {
  if (!type || !content) return null
  const mediaTypes = new Set([
    'imageMessage', 'videoMessage', 'audioMessage', 'documentMessage',
    'stickerMessage', 'ptvMessage', 'documentWithCaptionMessage',
  ])
  if (!mediaTypes.has(type) && !content?.mediaKey) return null

  return {
    type,
    mimetype: content.mimetype || '',
    fileLength: content.fileLength || 0,
    fileSha256: content.fileSha256,
    fileEncSha256: content.fileEncSha256,
    mediaKey: content.mediaKey,
    url: content.url || '',
    directPath: content.directPath || '',
    mediaKeyTimestamp: content.mediaKeyTimestamp,
    jpegThumbnail: content.jpegThumbnail || null,
    height: content.height || null,
    width: content.width || null,
    seconds: content.seconds || null,
    fileName: content.fileName || null,
    caption: content.caption || '',
  }
}

function extractLocationInfo(type, content) {
  if (!['locationMessage', 'liveLocationMessage'].includes(type)) return null
  return {
    lat: content?.degreesLatitude,
    lng: content?.degreesLongitude,
    name: content?.name || '',
    address: content?.address || '',
    url: content?.url || '',
    isLive: type === 'liveLocationMessage',
    accuracy: content?.accuracyInMeters || null,
    speed: content?.speedInMps || null,
  }
}

function extractPollInfo(type, content) {
  if (!type || !/^pollCreationMessage/.test(type)) return null
  return {
    name: content?.name || '',
    options: content?.options?.map(option => option.optionName).filter(Boolean) || [],
    selectableCount: content?.selectableOptionsCount || 1,
  }
}

function extractButtonInfo(type, content) {
  if (type === 'buttonsResponseMessage') {
    return { type: 'buttonReply', id: content?.selectedButtonId, text: content?.selectedDisplayText }
  }
  if (type === 'listResponseMessage') {
    return {
      type: 'listReply',
      id: content?.singleSelectReply?.selectedRowId,
      title: content?.title,
      description: content?.description,
    }
  }
  if (type === 'templateButtonReplyMessage') {
    return {
      type: 'templateReply',
      id: content?.selectedId,
      text: content?.selectedDisplayText,
      index: content?.selectedIndex,
    }
  }
  if (type === 'interactiveResponseMessage') {
    const params = content?.nativeFlowResponseMessage?.paramsJson
    try {
      const parsed = typeof params === 'string' ? JSON.parse(params) : {}
      return { type: 'interactiveReply', id: parsed?.id, title: parsed?.title, raw: parsed }
    } catch {
      return { type: 'interactiveReply', raw: content }
    }
  }
  return null
}

export async function extractMessageContent(rawMsg, sock) {
  try {
    const original = rawMsg?.message
    if (!original) return null

    const inner = unwrapMessage(original)
    const type = getContentType(inner) || 'unknown'
    const content = type === 'conversation' ? inner.conversation : inner?.[type]
    const from = rawMsg.key?.remoteJid || ''
    const isGroup = from.endsWith('@g.us')
    const isChannel = from.endsWith('@newsletter')
    const sender = isGroup
      ? (rawMsg.key?.participant || rawMsg.participant || '')
      : from

    const timestamp = typeof rawMsg.messageTimestamp === 'object'
      ? (rawMsg.messageTimestamp?.low ?? rawMsg.messageTimestamp?.toNumber?.())
      : rawMsg.messageTimestamp

    return {
      key: rawMsg.key,
      type,
      from,
      fromNumber: from.split('@')[0] || '',
      sender,
      senderNumber: sender.split('@')[0] || '',
      isGroup,
      isChannel,
      isDM: !isGroup && !isChannel,
      text: extractText(inner, type, content),
      caption: content?.caption || null,
      quoted: extractQuoted(content),
      mentions: content?.contextInfo?.mentionedJid || [],
      media: extractMediaInfo(type, content),
      poll: extractPollInfo(type, content),
      reaction: type === 'reactionMessage'
        ? { text: content?.text || '', key: content?.key }
        : null,
      location: extractLocationInfo(type, content),
      button: extractButtonInfo(type, content),
      pushName: rawMsg.pushName || '',
      timestamp,
      messageId: rawMsg.key?.id || '',
      raw: rawMsg,
      inner,
      content,
      // For forward compatibility, expose the full protobuf payload even when
      // this version of the parser does not yet know its semantic fields.
      rawTypeContent: content,
    }
  } catch {
    return null
  }
}

export async function downloadMedia(rawMsg, sock, outputType = 'buffer') {
  try {
    return await downloadMediaMessage(
      rawMsg,
      outputType === 'stream' ? 'stream' : 'buffer',
      {},
      {
        logger: sock?.logger || console,
        reuploadRequest: sock?.updateMediaMessage,
      }
    )
  } catch (err) {
    throw new Error(`Gagal download media: ${err.message}`)
  }
}
