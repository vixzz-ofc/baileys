import {
  getContentType,
  downloadMediaMessage,
  extractMessageContent as baileysExtract,
} from '@whiskeysockets/baileys'

// ─────────────────────────────────────────────────────────────────────────────
//  WRAPPER TYPES — semua jenis pembungkus pesan WA, termasuk yang terbaru
// ─────────────────────────────────────────────────────────────────────────────
const WRAPPER_TYPES = new Set([
  'ephemeralMessage',
  'viewOnceMessage',
  'viewOnceMessageV2',
  'viewOnceMessageV2Extension',
  'documentWithCaptionMessage',
  'deviceSentMessage',
  'editedMessage',
  'botForwardedMessage',
  'botInvokeMessage',
  'associatedChildMessage',
  'groupStatusMessage',
  'groupStatusMessageV2',
  'groupStatusMentionMessage',
  'groupMentionedMessage',
  'lottieStickerMessage',
  'limitSharingMessage',
  'statusMentionMessage',
  'statusAddYours',
  'eventCoverImage',
  'pollCreationMessageV4',
  'questionMessage',
  'questionReplyMessage',
  'botTaskMessage',
])

// ─────────────────────────────────────────────────────────────────────────────
//  MEDIA TYPES — semua type yang memiliki attachment media
// ─────────────────────────────────────────────────────────────────────────────
const MEDIA_TYPES = new Set([
  'imageMessage',
  'videoMessage',
  'audioMessage',
  'documentMessage',
  'stickerMessage',
  'ptvMessage',
  'documentWithCaptionMessage',
])

// ─────────────────────────────────────────────────────────────────────────────
//  INTERNAL PROTOCOL TYPES — jangan diproses sebagai command/user message
// ─────────────────────────────────────────────────────────────────────────────
export const SKIP_TYPES = new Set([
  'protocolMessage',
  'senderKeyDistributionMessage',
  'fastRatchetKeySenderKeyDistributionMessage',
  'stickerSyncRmrMessage',
  'messageHistoryBundle',
  'secretEncryptedMessage',
  'encCommentMessage',
  'encReactionMessage',
  'encEventResponseMessage',
])

/**
 * Unwrap semua wrapper pesan WA hingga dapat inner content asli.
 * Support sampai 16 level nesting (edge case ephemeral + viewOnce + edited).
 */
function unwrapMessage(message) {
  let current = message

  for (let i = 0; i < 16 && current && typeof current === 'object'; i++) {
    const type = getContentType(current)
    if (!type || !WRAPPER_TYPES.has(type)) break

    const wrapped = current[type]
    const next = wrapped?.message
      || wrapped?.editedMessage?.message
      || wrapped?.futureproofMessage?.message

    if (!next || next === current) break
    current = next
  }

  // Baileys extractor untuk compatibility dengan versi baru
  try {
    const extracted = baileysExtract(message)
    if (extracted && getContentType(extracted)) current = extracted
  } catch {}

  return current || message
}

/**
 * Extract text dari berbagai jenis pesan — support semua proto type WA terbaru
 */
function extractText(inner, type, content) {
  if (!inner || !type) return ''

  // Conversation biasa
  if (type === 'conversation') return inner.conversation || ''

  // Cek text/caption langsung
  const directText = [
    content?.text,
    content?.caption,
    content?.selectedButtonId,
    content?.selectedDisplayText,
    content?.selectedId,
    content?.singleSelectReply?.selectedRowId,
    content?.nativeFlowResponseMessage?.name,
    content?.name,
    content?.displayName,
    content?.body?.text,
    content?.message,
  ].find(v => typeof v === 'string' && v.length > 0)

  if (directText) return directText

  // Interactive response
  if (type === 'interactiveResponseMessage') {
    const params = content?.nativeFlowResponseMessage?.paramsJson
    if (typeof params === 'string') {
      try {
        const p = JSON.parse(params)
        return p?.id || p?.title || p?.name || ''
      } catch {}
    }
  }

  // Question response
  if (type === 'questionResponseMessage') {
    return content?.selectedOptionName || content?.response || ''
  }

  // Event message
  if (type === 'eventMessage') {
    return content?.name ? `[Event] ${content.name}` : '[Event]'
  }

  // Album message
  if (type === 'albumMessage') {
    const count = Array.isArray(content?.messages) ? content.messages.length : 0
    return `[Album: ${count} media]`
  }

  // Comment message (channel)
  if (type === 'commentMessage') {
    return content?.message?.extendedTextMessage?.text
      || content?.message?.conversation
      || '[Comment]'
  }

  // AI/Bot rich response
  if (type === 'richResponseMessage') {
    return content?.message?.conversation
      || content?.message?.extendedTextMessage?.text
      || '[AI Response]'
  }

  // Scheduled call
  if (type === 'scheduledCallCreationMessage') {
    return `[Scheduled Call: ${content?.title || 'Untitled'}]`
  }
  if (type === 'scheduledCallEditMessage') {
    return `[Scheduled Call Edit: ${content?.title || ''}]`
  }

  // Newsletter admin invite
  if (type === 'newsletterAdminInviteMessage') {
    return `[Channel Admin Invite: ${content?.newsletterName || ''}]`
  }

  // Newsletter follower invite
  if (type === 'newsletterFollowerInviteMessageV2') {
    return `[Channel Invite: ${content?.newsletterName || ''}]`
  }

  // Sticker pack
  if (type === 'stickerPackMessage') {
    return `[Sticker Pack: ${content?.name || ''}]`
  }

  // Status notification
  if (type === 'statusNotificationMessage') {
    return '[Status Notification]'
  }

  // Status question answer
  if (type === 'statusQuestionAnswerMessage') {
    return content?.answer || '[Status Q&A]'
  }

  // Status quoted
  if (type === 'statusQuotedMessage') {
    return '[Status Reply]'
  }

  // Status sticker interaction
  if (type === 'statusStickerInteractionMessage') {
    return '[Status Sticker]'
  }

  // Placeholder (media di-remove)
  if (type === 'placeholderMessage') {
    return '[Pesan telah dihapus]'
  }

  // BCall (broadcast call)
  if (type === 'bcallMessage') {
    return '[Group Call]'
  }

  // Call log
  if (type === 'callLogMesssage') return '[Call Log]'

  // Group invite
  if (type === 'groupInviteMessage') {
    return content?.caption || `[Undangan Grup: ${content?.groupName || ''}]`
  }

  // Order
  if (type === 'orderMessage') return `[Order: ${content?.orderId || ''}]`

  // Product
  if (type === 'productMessage') return content?.product?.productImage?.caption || '[Product]'

  // Contacts array
  if (type === 'contactsArrayMessage') {
    return content?.contacts?.map(c => c.displayName).filter(Boolean).join(', ') || '[Contacts]'
  }

  // Poll (semua versi v1-v5)
  if (type === 'pollCreationMessage'
    || /^pollCreationMessageV\d+$/.test(type)) {
    return content?.name || '[Poll]'
  }

  // Poll update (vote)
  if (type === 'pollUpdateMessage') return '[Poll Vote]'

  // Poll result snapshot (semua versi)
  if (type === 'pollResultSnapshotMessage' || type === 'pollResultSnapshotMessageV3') {
    return '[Poll Result]'
  }

  // Reaction
  if (type === 'reactionMessage') return content?.text || ''
  if (type === 'encReactionMessage') return '[Encrypted Reaction]'

  // Pin
  if (type === 'pinInChatMessage') return '[Pin Message]'

  // Keep in chat
  if (type === 'keepInChatMessage') return '[Keep in Chat]'

  // Payment
  if (type === 'requestPaymentMessage') return `[Payment Request: ${content?.amount1000 ? content.amount1000 / 1000 : '?'} ${content?.currencyCodeIso4217 || ''}]`
  if (type === 'sendPaymentMessage') return '[Payment Sent]'
  if (type === 'cancelPaymentRequestMessage') return '[Payment Cancelled]'
  if (type === 'declinePaymentRequestMessage') return '[Payment Declined]'
  if (type === 'paymentInviteMessage') return '[Payment Invite]'

  // Request phone number
  if (type === 'requestPhoneNumberMessage') return '[Request Phone Number]'

  // Invoice
  if (type === 'invoiceMessage') return '[Invoice]'

  // PTV (video message/story video)
  if (type === 'ptvMessage') return '[Video Note]'

  return ''
}

/**
 * Extract quoted message context
 */
function extractQuoted(content) {
  const ctx = content?.contextInfo
  if (!ctx?.quotedMessage) return null

  const quotedType = getContentType(ctx.quotedMessage)
  const quotedContent = quotedType ? ctx.quotedMessage[quotedType] : null

  return {
    type: quotedType || 'unknown',
    sender: ctx.participant || ctx.remoteJid || '',
    stanzaId: ctx.stanzaId || '',
    text: extractText(ctx.quotedMessage, quotedType, quotedContent),
    content: quotedContent,
    raw: ctx.quotedMessage,
  }
}

/**
 * Extract media info dari message
 */
function extractMediaInfo(type, content) {
  if (!type || !content) return null
  if (!MEDIA_TYPES.has(type) && !content?.mediaKey) return null

  return {
    type,
    mimetype: content.mimetype || '',
    fileLength: content.fileLength || 0,
    fileSha256: content.fileSha256 || null,
    fileEncSha256: content.fileEncSha256 || null,
    mediaKey: content.mediaKey || null,
    url: content.url || '',
    directPath: content.directPath || '',
    mediaKeyTimestamp: content.mediaKeyTimestamp || null,
    jpegThumbnail: content.jpegThumbnail || null,
    height: content.height || null,
    width: content.width || null,
    seconds: content.seconds || null,
    fileName: content.fileName || null,
    caption: content.caption || '',
    isAnimated: content.isAnimated || false,
    isGif: content.gifPlayback || false,
    isViewOnce: content.viewOnce || false,
  }
}

/**
 * Extract location info
 */
function extractLocationInfo(type, content) {
  if (!['locationMessage', 'liveLocationMessage'].includes(type)) return null
  return {
    lat: content?.degreesLatitude ?? null,
    lng: content?.degreesLongitude ?? null,
    name: content?.name || '',
    address: content?.address || '',
    url: content?.url || '',
    isLive: type === 'liveLocationMessage',
    accuracy: content?.accuracyInMeters || null,
    speed: content?.speedInMps || null,
    bearing: content?.degreesClockwiseFromMagneticNorth || null,
    caption: content?.caption || '',
  }
}

/**
 * Extract poll info (support v1-v5)
 */
function extractPollInfo(type, content) {
  if (!type || !/^pollCreationMessage/.test(type)) return null
  return {
    version: type.replace('pollCreationMessage', '') || 'v1',
    name: content?.name || '',
    options: content?.options?.map(o => o.optionName).filter(Boolean) || [],
    selectableCount: content?.selectableOptionsCount ?? 1,
    messageSecret: content?.pollCreationMessageSecret || null,
    toAnnouncementGroup: content?.toAnnouncementGroup || false,
  }
}

/**
 * Extract poll update (vote) info
 */
function extractPollUpdateInfo(type, content) {
  if (type !== 'pollUpdateMessage') return null
  return {
    pollCreationMessageKey: content?.pollCreationMessageKey || null,
    vote: content?.vote || null,
  }
}

/**
 * Extract button/interactive reply info
 */
function extractButtonInfo(type, content) {
  if (type === 'buttonsResponseMessage') {
    return {
      type: 'buttonReply',
      id: content?.selectedButtonId,
      text: content?.selectedDisplayText,
    }
  }
  if (type === 'listResponseMessage') {
    return {
      type: 'listReply',
      id: content?.singleSelectReply?.selectedRowId,
      title: content?.title,
      description: content?.description,
    }
  }
  if (type === 'templateButtonReplyMessage') {
    return {
      type: 'templateReply',
      id: content?.selectedId,
      text: content?.selectedDisplayText,
      index: content?.selectedIndex,
    }
  }
  if (type === 'interactiveResponseMessage') {
    const params = content?.nativeFlowResponseMessage?.paramsJson
    try {
      const parsed = typeof params === 'string' ? JSON.parse(params) : {}
      return {
        type: 'interactiveReply',
        id: parsed?.id,
        title: parsed?.title,
        name: content?.nativeFlowResponseMessage?.name,
        raw: parsed,
      }
    } catch {
      return { type: 'interactiveReply', raw: content }
    }
  }
  if (type === 'questionResponseMessage') {
    return {
      type: 'questionReply',
      selectedOption: content?.selectedOptionName,
      response: content?.response,
    }
  }
  return null
}

/**
 * Extract event message info
 */
function extractEventInfo(type, content) {
  if (type !== 'eventMessage') return null
  return {
    name: content?.name || '',
    description: content?.description || '',
    startTime: content?.startTime ? new Date(Number(content.startTime) * 1000) : null,
    endTime: content?.endTime ? new Date(Number(content.endTime) * 1000) : null,
    location: content?.location ? {
      lat: content.location.degreesLatitude,
      lng: content.location.degreesLongitude,
      name: content.location.name || '',
    } : null,
    joinLink: content?.joinLink || '',
    isCanceled: content?.isCanceled || false,
    extraGuestsAllowed: content?.extraGuestsAllowed || false,
  }
}

/**
 * Extract album message info
 */
function extractAlbumInfo(type, content) {
  if (type !== 'albumMessage') return null
  const msgs = Array.isArray(content?.messages) ? content.messages : []
  return {
    count: msgs.length,
    mediaList: msgs.map((m, i) => {
      const mType = getContentType(m?.message || m)
      const mContent = (m?.message || m)?.[mType]
      return {
        index: i,
        type: mType,
        mimetype: mContent?.mimetype || '',
        caption: mContent?.caption || '',
        mediaKey: mContent?.mediaKey || null,
        url: mContent?.url || '',
      }
    }),
  }
}

/**
 * Extract reaction info
 */
function extractReactionInfo(type, content) {
  if (type !== 'reactionMessage') return null
  return {
    emoji: content?.text || '',
    key: content?.key || null,
    senderTimestampMs: content?.senderTimestampMs || null,
    isRemove: !content?.text,
  }
}

/**
 * Extract scheduled call info
 */
function extractScheduledCallInfo(type, content) {
  if (type !== 'scheduledCallCreationMessage' && type !== 'scheduledCallEditMessage') return null
  return {
    isEdit: type === 'scheduledCallEditMessage',
    title: content?.title || '',
    scheduledTimestamp: content?.scheduledTimestamp || null,
    duration: content?.duration || null,
    callType: content?.callType || null,
  }
}

/**
 * Extract payment info
 */
function extractPaymentInfo(type, content) {
  const paymentTypes = [
    'requestPaymentMessage', 'sendPaymentMessage',
    'cancelPaymentRequestMessage', 'declinePaymentRequestMessage',
    'paymentInviteMessage',
  ]
  if (!paymentTypes.includes(type)) return null
  return {
    paymentType: type.replace('Message', ''),
    amount: content?.amount1000 ? content.amount1000 / 1000 : null,
    currency: content?.currencyCodeIso4217 || '',
    noteMessage: content?.noteMessage?.extendedTextMessage?.text
      || content?.noteMessage?.conversation || '',
    expiryTimestamp: content?.expiryTimestamp || null,
    status: content?.paymentStatus || null,
  }
}

/**
 * Main extractor — normalize semua jenis pesan WA ke format standar
 */
export async function extractMessageContent(rawMsg, sock) {
  try {
    const original = rawMsg?.message
    if (!original) return null

    const inner = unwrapMessage(original)
    const type = getContentType(inner) || 'unknown'
    const content = type === 'conversation' ? inner : inner?.[type]
    const from = rawMsg.key?.remoteJid || ''
    const isGroup = from.endsWith('@g.us')
    const isChannel = from.endsWith('@newsletter')
    const isStatus = from === 'status@broadcast'
    const sender = isGroup
      ? (rawMsg.key?.participant || rawMsg.participant || '')
      : from

    const timestamp = typeof rawMsg.messageTimestamp === 'object'
      ? (rawMsg.messageTimestamp?.low ?? rawMsg.messageTimestamp?.toNumber?.() ?? 0)
      : (rawMsg.messageTimestamp ?? 0)

    return {
      // ── identitas ──────────────────────────────────────────────────────────
      key: rawMsg.key,
      messageId: rawMsg.key?.id || '',
      type,

      // ── asal pesan ─────────────────────────────────────────────────────────
      from,
      fromNumber: from.split('@')[0] || '',
      sender,
      senderNumber: sender.split('@')[0] || '',
      isGroup,
      isChannel,
      isDM: !isGroup && !isChannel && !isStatus,
      isStatus,
      isFromMe: rawMsg.key?.fromMe || false,

      // ── konten utama ───────────────────────────────────────────────────────
      text: extractText(inner, type, content),
      caption: type !== 'conversation' ? (content?.caption || null) : null,
      pushName: rawMsg.pushName || '',
      timestamp,

      // ── fitur spesifik ─────────────────────────────────────────────────────
      quoted: extractQuoted(content),
      mentions: content?.contextInfo?.mentionedJid || [],
      media: extractMediaInfo(type, content),
      location: extractLocationInfo(type, content),
      poll: extractPollInfo(type, content),
      pollUpdate: extractPollUpdateInfo(type, content),
      reaction: extractReactionInfo(type, content),
      button: extractButtonInfo(type, content),
      event: extractEventInfo(type, content),
      album: extractAlbumInfo(type, content),
      scheduledCall: extractScheduledCallInfo(type, content),
      payment: extractPaymentInfo(type, content),

      // ── context info ───────────────────────────────────────────────────────
      contextInfo: content?.contextInfo || null,
      isForwarded: (content?.contextInfo?.isForwarded || false),
      forwardingScore: content?.contextInfo?.forwardingScore || 0,
      isEphemeral: !!original?.ephemeralMessage,
      isViewOnce: !!(original?.viewOnceMessage || original?.viewOnceMessageV2 || original?.viewOnceMessageV2Extension),
      isEdited: !!original?.editedMessage,

      // ── newsletter/channel ─────────────────────────────────────────────────
      newsletterName: rawMsg.key?.newsletterName || '',
      serverID: rawMsg.key?.serverID || null,

      // ── raw access ─────────────────────────────────────────────────────────
      raw: rawMsg,
      inner,
      content,
      // Forward compat: raw proto content untuk type yang belum dikenali
      rawTypeContent: content,
    }
  } catch (err) {
    return null
  }
}

/**
 * Download media dari message
 * @param {object} rawMsg — raw WAMessage
 * @param {object} sock — socket baileys
 * @param {'buffer'|'stream'} outputType
 */
export async function downloadMedia(rawMsg, sock, outputType = 'buffer') {
  try {
    return await downloadMediaMessage(
      rawMsg,
      outputType === 'stream' ? 'stream' : 'buffer',
      {},
      {
        logger: sock?.logger || console,
        reuploadRequest: sock?.updateMediaMessage,
      }
    )
  } catch (err) {
    throw new Error(`Gagal download media: ${err.message}`)
  }
}

/**
 * Cek apakah message adalah command berdasarkan prefix
 */
export function isCommand(text, prefix) {
  return typeof text === 'string' && text.startsWith(prefix)
}

/**
 * Parse command dari text
 */
export function parseCommand(text, prefix) {
  if (!isCommand(text, prefix)) return null
  const body = text.slice(prefix.length).trim()
  const args = body.split(/\s+/)
  return {
    command: args[0]?.toLowerCase() || '',
    args: args.slice(1),
    body,
    fullText: text,
  }
}

/**
 * Re-export SKIP_TYPES untuk dipakai di handler
 */
export { WRAPPER_TYPES, MEDIA_TYPES }
