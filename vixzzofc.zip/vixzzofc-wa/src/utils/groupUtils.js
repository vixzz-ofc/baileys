// ─── group utilities ──────────────────────────────────────────────────────────

// get group metadata
export async function getGroupMeta(sock, jid) {
  try {
    return await sock.groupMetadata(jid)
  } catch {
    return null
  }
}

// cek apakah sender adalah admin group
export async function isGroupAdmin(sock, jid, participantJid) {
  try {
    const meta = await sock.groupMetadata(jid)
    const admins = meta.participants
      .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
      .map(p => p.id)
    return admins.includes(participantJid)
  } catch {
    return false
  }
}

// cek apakah bot adalah admin group
export async function isBotAdmin(sock, jid) {
  try {
    const botJid = sock.user?.id?.replace(':0', '')?.split(':')[0] + '@s.whatsapp.net'
    return await isGroupAdmin(sock, jid, botJid)
  } catch {
    return false
  }
}

// get daftar admin
export async function getGroupAdmins(sock, jid) {
  try {
    const meta = await sock.groupMetadata(jid)
    return meta.participants
      .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
      .map(p => p.id)
  } catch {
    return []
  }
}

// add member ke group
export async function addMember(sock, jid, numbers) {
  return await sock.groupParticipantsUpdate(jid, numbers, 'add')
}

// kick member dari group
export async function kickMember(sock, jid, numbers) {
  return await sock.groupParticipantsUpdate(jid, numbers, 'remove')
}

// promote member jadi admin
export async function promoteMember(sock, jid, numbers) {
  return await sock.groupParticipantsUpdate(jid, numbers, 'promote')
}

// demote admin jadi member
export async function demoteMember(sock, jid, numbers) {
  return await sock.groupParticipantsUpdate(jid, numbers, 'demote')
}

// update nama group
export async function updateGroupName(sock, jid, name) {
  return await sock.groupUpdateSubject(jid, name)
}

// update deskripsi group
export async function updateGroupDesc(sock, jid, description) {
  return await sock.groupUpdateDescription(jid, description)
}

// update setting group (siapa yang bisa kirim)
export async function updateGroupSetting(sock, jid, setting) {
  // setting: 'announcement' | 'not_announcement' | 'locked' | 'unlocked'
  return await sock.groupSettingUpdate(jid, setting)
}

// invite link group
export async function getGroupInviteLink(sock, jid) {
  const code = await sock.groupInviteCode(jid)
  return `https://chat.whatsapp.com/${code}`
}

// revoke invite link
export async function revokeGroupInviteLink(sock, jid) {
  return await sock.groupRevokeInvite(jid)
}
