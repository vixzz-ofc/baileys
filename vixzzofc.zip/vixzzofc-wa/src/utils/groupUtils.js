// ─────────────────────────────────────────────────────────────────────────────
//  GROUP UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

/** Get metadata group */
export async function getGroupMeta(sock, jid) {
  try {
    return await sock.groupMetadata(jid)
  } catch {
    return null
  }
}

/** Cek apakah participant adalah admin */
export async function isGroupAdmin(sock, jid, participantJid) {
  try {
    const meta = await sock.groupMetadata(jid)
    const admins = meta.participants
      .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
      .map(p => p.id)
    return admins.includes(participantJid)
  } catch {
    return false
  }
}

/** Cek apakah bot adalah admin */
export async function isBotAdmin(sock, jid) {
  try {
    const botJid = sock.user?.id?.replace(/:0$/, '')?.split(':')[0] + '@s.whatsapp.net'
    return await isGroupAdmin(sock, jid, botJid)
  } catch {
    return false
  }
}

/** Get JID bot */
export function getBotJid(sock) {
  return sock.user?.id?.replace(/:0$/, '')?.split(':')[0] + '@s.whatsapp.net'
}

/** Get list admin group */
export async function getGroupAdmins(sock, jid) {
  try {
    const meta = await sock.groupMetadata(jid)
    return meta.participants
      .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
      .map(p => p.id)
  } catch {
    return []
  }
}

/** Get list semua member group */
export async function getGroupMembers(sock, jid) {
  try {
    const meta = await sock.groupMetadata(jid)
    return meta.participants.map(p => p.id)
  } catch {
    return []
  }
}

/** Get jumlah member group */
export async function getGroupMemberCount(sock, jid) {
  try {
    const meta = await sock.groupMetadata(jid)
    return meta.participants.length
  } catch {
    return 0
  }
}

/** Add member ke group */
export async function addMember(sock, jid, numbers) {
  return await sock.groupParticipantsUpdate(jid, Array.isArray(numbers) ? numbers : [numbers], 'add')
}

/** Kick member dari group */
export async function kickMember(sock, jid, numbers) {
  return await sock.groupParticipantsUpdate(jid, Array.isArray(numbers) ? numbers : [numbers], 'remove')
}

/** Promote member jadi admin */
export async function promoteMember(sock, jid, numbers) {
  return await sock.groupParticipantsUpdate(jid, Array.isArray(numbers) ? numbers : [numbers], 'promote')
}

/** Demote admin jadi member */
export async function demoteMember(sock, jid, numbers) {
  return await sock.groupParticipantsUpdate(jid, Array.isArray(numbers) ? numbers : [numbers], 'demote')
}

/** Update nama group */
export async function updateGroupName(sock, jid, name) {
  return await sock.groupUpdateSubject(jid, name)
}

/** Update deskripsi group */
export async function updateGroupDesc(sock, jid, description) {
  return await sock.groupUpdateDescription(jid, description)
}

/**
 * Update setting group
 * @param {'announcement'|'not_announcement'|'locked'|'unlocked'} setting
 */
export async function updateGroupSetting(sock, jid, setting) {
  return await sock.groupSettingUpdate(jid, setting)
}

/** Get invite link group */
export async function getGroupInviteLink(sock, jid) {
  const code = await sock.groupInviteCode(jid)
  return `https://chat.whatsapp.com/${code}`
}

/** Revoke invite link lama dan generate yang baru */
export async function revokeGroupInviteLink(sock, jid) {
  return await sock.groupRevokeInvite(jid)
}

/** Join group via invite link */
export async function joinGroupViaLink(sock, inviteCode) {
  return await sock.groupAcceptInvite(inviteCode)
}

/** Buat group baru */
export async function createGroup(sock, subject, participants = []) {
  return await sock.groupCreate(subject, participants)
}

/** Leave dari group */
export async function leaveGroup(sock, jid) {
  return await sock.groupLeave(jid)
}

/**
 * Approve/reject join request member di group (announce group)
 * @param {string[]} participants
 * @param {'approve'|'reject'} action
 */
export async function handleJoinRequest(sock, jid, participants, action = 'approve') {
  return await sock.groupRequestParticipantsUpdate(jid, participants, action)
}

/** Get join requests yang pending */
export async function getJoinRequests(sock, jid) {
  try {
    return await sock.groupRequestParticipantsList(jid)
  } catch {
    return []
  }
}

/**
 * Update foto grup
 * @param {Buffer} imageBuffer
 */
export async function updateGroupPicture(sock, jid, imageBuffer) {
  return await sock.updateProfilePicture(jid, imageBuffer)
}

/** Hapus foto grup */
export async function removeGroupPicture(sock, jid) {
  return await sock.removeProfilePicture(jid)
}
