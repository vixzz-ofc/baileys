import { proto, generateWAMessageFromContent, prepareWAMessageMedia } from '@whiskeysockets/baileys'
import fs from 'fs'

// ─── send plain text ──────────────────────────────────────────────────────────
export async function sendMessage(sock, jid, content, options = {}) {
  return await sock.sendMessage(jid, content, options)
}

// ─── send reply (quote) ───────────────────────────────────────────────────────
export async function sendReply(sock, rawMsg, text, extra = {}) {
  return await sock.sendMessage(
    rawMsg.key.remoteJid,
    { text, ...extra },
    { quoted: rawMsg }
  )
}

// ─── send image ───────────────────────────────────────────────────────────────
export async function sendImage(sock, jid, source, caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { image: { url: source }, caption }
    : { image: source, caption }

  return await sock.sendMessage(jid, { ...content, ...options })
}

// ─── send video ───────────────────────────────────────────────────────────────
export async function sendVideo(sock, jid, source, caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { video: { url: source }, caption }
    : { video: source, caption }

  return await sock.sendMessage(jid, { ...content, ...options })
}

// ─── send audio ───────────────────────────────────────────────────────────────
export async function sendAudio(sock, jid, source, isPtt = false, options = {}) {
  const content = typeof source === 'string'
    ? { audio: { url: source }, ptt: isPtt }
    : { audio: source, ptt: isPtt }

  return await sock.sendMessage(jid, { ...content, ...options })
}

// ─── send document ────────────────────────────────────────────────────────────
export async function sendDocument(sock, jid, source, fileName = 'file', mimetype = 'application/octet-stream', caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { document: { url: source }, fileName, mimetype, caption }
    : { document: source, fileName, mimetype, caption }

  return await sock.sendMessage(jid, { ...content, ...options })
}

// ─── send sticker ─────────────────────────────────────────────────────────────
export async function sendSticker(sock, jid, source, options = {}) {
  const content = typeof source === 'string'
    ? { sticker: { url: source } }
    : { sticker: source }

  return await sock.sendMessage(jid, { ...content, ...options })
}

// ─── send location ────────────────────────────────────────────────────────────
export async function sendLocation(sock, jid, lat, lng, name = '', address = '', options = {}) {
  return await sock.sendMessage(jid, {
    location: {
      degreesLatitude: lat,
      degreesLongitude: lng,
      name,
      address,
    },
    ...options,
  })
}

// ─── send contact ─────────────────────────────────────────────────────────────
export async function sendContact(sock, jid, displayName, number, options = {}) {
  const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${displayName}\nTEL;type=CELL;type=VOICE;waid=${number}:+${number}\nEND:VCARD`
  return await sock.sendMessage(jid, {
    contacts: {
      displayName,
      contacts: [{ vcard }],
    },
    ...options,
  })
}

// ─── send poll ────────────────────────────────────────────────────────────────
export async function sendPoll(sock, jid, pollName, options = [], selectableCount = 1, extra = {}) {
  return await sock.sendMessage(jid, {
    poll: {
      name: pollName,
      values: options,
      selectableCount,
    },
    ...extra,
  })
}

// ─── send reaction ────────────────────────────────────────────────────────────
export async function sendReaction(sock, jid, messageKey, emoji) {
  return await sock.sendMessage(jid, {
    react: {
      text: emoji,
      key: messageKey,
    },
  })
}

// ─── send buttons (interactive — fallback ke text jika unsupported) ──────────
export async function sendButtons(sock, jid, text, buttons = [], footer = '', quotedMsg = null) {
  const buttonContent = {
    text,
    footer,
    buttons: buttons.map((b, i) => ({
      buttonId: b.id || `btn_${i}`,
      buttonText: { displayText: b.text },
      type: 1,
    })),
    headerType: 1,
  }

  const opts = quotedMsg ? { quoted: quotedMsg } : {}

  try {
    return await sock.sendMessage(jid, buttonContent, opts)
  } catch {
    // fallback ke text biasa
    const fallback = `${text}\n\n${buttons.map((b, i) => `${i + 1}. ${b.text}`).join('\n')}`
    return await sock.sendMessage(jid, { text: fallback }, opts)
  }
}

// ─── send list ────────────────────────────────────────────────────────────────
export async function sendList(sock, jid, title, text, buttonText, sections = [], footer = '', quotedMsg = null) {
  const listContent = {
    text,
    footer,
    title,
    buttonText,
    sections,
  }

  const opts = quotedMsg ? { quoted: quotedMsg } : {}

  try {
    return await sock.sendMessage(jid, listContent, opts)
  } catch {
    // fallback
    const fallback = `*${title}*\n${text}\n\n${sections.map(s =>
      `*${s.title}*\n${s.rows.map(r => `- ${r.title}`).join('\n')}`
    ).join('\n\n')}`
    return await sock.sendMessage(jid, { text: fallback }, opts)
  }
}

// ─── send dengan typing indicator ────────────────────────────────────────────
export async function sendWithTyping(sock, jid, content, delayMs = 1500) {
  await sock.sendPresenceUpdate('composing', jid)
  await new Promise((r) => setTimeout(r, delayMs))
  await sock.sendPresenceUpdate('paused', jid)
  return await sock.sendMessage(jid, content)
}

// ─── forward message ──────────────────────────────────────────────────────────
export async function forwardMessage(sock, jid, rawMsg, force = true) {
  return await sock.sendMessage(jid, { forward: rawMsg, force })
}

// ─── delete message ───────────────────────────────────────────────────────────
export async function deleteMessage(sock, jid, msgKey) {
  return await sock.sendMessage(jid, { delete: msgKey })
}

// ─── edit message ─────────────────────────────────────────────────────────────
export async function editMessage(sock, jid, msgKey, newText) {
  return await sock.sendMessage(jid, {
    text: newText,
    edit: msgKey,
  })
}

// ─── pin message ─────────────────────────────────────────────────────────────
export async function pinMessage(sock, jid, msgKey, duration = 86400) {
  return await sock.sendMessage(jid, {
    pin: msgKey,
    type: proto.PinInChat.Type.PIN_FOR_ALL,
    time: duration,
  })
}

// ─── newsletter follow ────────────────────────────────────────────────────────
export async function followChannel(sock, jid) {
  return await sock.newsletterFollow(jid)
}

// ─── newsletter unfollow ──────────────────────────────────────────────────────
export async function unfollowChannel(sock, jid) {
  return await sock.newsletterUnfollow(jid)
}
