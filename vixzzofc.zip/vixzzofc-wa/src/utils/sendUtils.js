import { proto } from '@whiskeysockets/baileys'
import fs from 'fs'

// ─────────────────────────────────────────────────────────────────────────────
//  BASIC SEND
// ─────────────────────────────────────────────────────────────────────────────

/** Kirim pesan apapun langsung */
export async function sendMessage(sock, jid, content, options = {}) {
  return await sock.sendMessage(jid, content, options)
}

/** Kirim text dengan quote */
export async function sendReply(sock, rawMsg, text, extra = {}) {
  return await sock.sendMessage(
    rawMsg.key?.remoteJid || rawMsg.from,
    { text, ...extra },
    { quoted: rawMsg }
  )
}

/** Kirim text biasa tanpa quote */
export async function sendText(sock, jid, text, options = {}) {
  return await sock.sendMessage(jid, { text }, options)
}

// ─────────────────────────────────────────────────────────────────────────────
//  MEDIA
// ─────────────────────────────────────────────────────────────────────────────

/** Kirim image dari URL, path file, atau Buffer */
export async function sendImage(sock, jid, source, caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { image: { url: source }, caption }
    : { image: source, caption }
  return await sock.sendMessage(jid, { ...content, ...options })
}

/** Kirim video dari URL, path file, atau Buffer */
export async function sendVideo(sock, jid, source, caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { video: { url: source }, caption }
    : { video: source, caption }
  return await sock.sendMessage(jid, { ...content, ...options })
}

/** Kirim audio — ptt=true untuk voice note */
export async function sendAudio(sock, jid, source, isPtt = false, options = {}) {
  const content = typeof source === 'string'
    ? { audio: { url: source }, ptt: isPtt }
    : { audio: source, ptt: isPtt }
  return await sock.sendMessage(jid, { ...content, ...options })
}

/** Kirim dokumen/file */
export async function sendDocument(sock, jid, source, fileName = 'file', mimetype = 'application/octet-stream', caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { document: { url: source }, fileName, mimetype, caption }
    : { document: source, fileName, mimetype, caption }
  return await sock.sendMessage(jid, { ...content, ...options })
}

/** Kirim sticker */
export async function sendSticker(sock, jid, source, options = {}) {
  const content = typeof source === 'string'
    ? { sticker: { url: source } }
    : { sticker: source }
  return await sock.sendMessage(jid, { ...content, ...options })
}

/**
 * Kirim PTV (Personal Video / Video Note — lingkaran seperti di Telegram)
 * Baileys menggunakan { video, ptv: true }
 */
export async function sendPTV(sock, jid, source, options = {}) {
  const content = typeof source === 'string'
    ? { video: { url: source }, ptv: true }
    : { video: source, ptv: true }
  return await sock.sendMessage(jid, { ...content, ...options })
}

/**
 * Kirim album (multiple image/video dalam satu pesan)
 * @param {Array} mediaArray — [{ image/video: Buffer|{url}, caption: '' }, ...]
 */
export async function sendAlbum(sock, jid, mediaArray = [], options = {}) {
  if (!Array.isArray(mediaArray) || mediaArray.length === 0) {
    throw new Error('sendAlbum: mediaArray harus berisi minimal 1 item')
  }
  return await sock.sendMessage(jid, { albumMessage: mediaArray }, options)
}

// ─────────────────────────────────────────────────────────────────────────────
//  LOCATION
// ─────────────────────────────────────────────────────────────────────────────

/** Kirim lokasi */
export async function sendLocation(sock, jid, lat, lng, name = '', address = '', options = {}) {
  return await sock.sendMessage(jid, {
    location: {
      degreesLatitude: lat,
      degreesLongitude: lng,
      name,
      address,
    },
    ...options,
  })
}

/** Kirim live location */
export async function sendLiveLocation(sock, jid, lat, lng, caption = '', durationSeconds = 60, options = {}) {
  return await sock.sendMessage(jid, {
    liveLocation: {
      degreesLatitude: lat,
      degreesLongitude: lng,
      caption,
      accuracyInMeters: 10,
    },
    ...options,
  })
}

// ─────────────────────────────────────────────────────────────────────────────
//  CONTACT
// ─────────────────────────────────────────────────────────────────────────────

/** Kirim satu kontak */
export async function sendContact(sock, jid, displayName, number, options = {}) {
  const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${displayName}\nTEL;type=CELL;type=VOICE;waid=${number}:+${number}\nEND:VCARD`
  return await sock.sendMessage(jid, {
    contacts: {
      displayName,
      contacts: [{ vcard }],
    },
    ...options,
  })
}

/** Kirim multiple kontak sekaligus */
export async function sendContacts(sock, jid, contactList = [], options = {}) {
  // contactList: [{ displayName, number }, ...]
  const contacts = contactList.map(c => ({
    vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${c.displayName}\nTEL;type=CELL;type=VOICE;waid=${c.number}:+${c.number}\nEND:VCARD`,
    displayName: c.displayName,
  }))
  const displayName = contactList.length > 1
    ? `${contactList[0].displayName} & ${contactList.length - 1} lainnya`
    : contactList[0]?.displayName || ''
  return await sock.sendMessage(jid, {
    contacts: { displayName, contacts },
    ...options,
  })
}

// ─────────────────────────────────────────────────────────────────────────────
//  POLL
// ─────────────────────────────────────────────────────────────────────────────

/** Kirim poll */
export async function sendPoll(sock, jid, pollName, values = [], selectableCount = 1, extra = {}) {
  return await sock.sendMessage(jid, {
    poll: {
      name: pollName,
      values,
      selectableCount,
    },
    ...extra,
  })
}

// ─────────────────────────────────────────────────────────────────────────────
//  REACTION
// ─────────────────────────────────────────────────────────────────────────────

/** Kirim/tambah emoji reaction ke sebuah pesan */
export async function sendReaction(sock, jid, messageKey, emoji) {
  return await sock.sendMessage(jid, {
    react: {
      text: emoji,
      key: messageKey,
    },
  })
}

/** Hapus reaction dari sebuah pesan */
export async function removeReaction(sock, jid, messageKey) {
  return await sock.sendMessage(jid, {
    react: {
      text: '',
      key: messageKey,
    },
  })
}

// ─────────────────────────────────────────────────────────────────────────────
//  INTERACTIVE MESSAGES
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Kirim button message (legacy — mungkin di-block WA di beberapa device)
 * Fallback otomatis ke text jika gagal
 */
export async function sendButtons(sock, jid, text, buttons = [], footer = '', quotedMsg = null) {
  const buttonContent = {
    text,
    footer,
    buttons: buttons.map((b, i) => ({
      buttonId: b.id || `btn_${i}`,
      buttonText: { displayText: b.text },
      type: 1,
    })),
    headerType: 1,
  }
  const opts = quotedMsg ? { quoted: quotedMsg } : {}
  try {
    return await sock.sendMessage(jid, buttonContent, opts)
  } catch {
    const fallback = `${text}\n\n${buttons.map((b, i) => `${i + 1}. ${b.text}`).join('\n')}`
    return await sock.sendMessage(jid, { text: fallback }, opts)
  }
}

/**
 * Kirim list message
 * @param {Array} sections — [{title, rows: [{id, title, description}]}]
 */
export async function sendList(sock, jid, title, text, buttonText, sections = [], footer = '', quotedMsg = null) {
  const opts = quotedMsg ? { quoted: quotedMsg } : {}
  try {
    return await sock.sendMessage(jid, {
      text,
      footer,
      title,
      buttonText,
      sections,
    }, opts)
  } catch {
    const fallback = `*${title}*\n${text}\n\n${sections.map(s =>
      `*${s.title}*\n${s.rows.map(r => `- ${r.title}`).join('\n')}`
    ).join('\n\n')}`
    return await sock.sendMessage(jid, { text: fallback }, opts)
  }
}

/**
 * Kirim interactive message (native flow — WA Business / terbaru)
 * @param {object} header — { title?, subtitle?, hasMediaAttachment?, imageMessage?, videoMessage?, documentMessage?, locationMessage? }
 * @param {object} body — { text }
 * @param {object} footer — { text }
 * @param {Array} nativeFlowButtons — array button native flow
 */
export async function sendInteractive(sock, jid, header, body, footer, nativeFlowButtons = [], quotedMsg = null) {
  const opts = quotedMsg ? { quoted: quotedMsg } : {}
  try {
    return await sock.sendMessage(jid, {
      interactiveMessage: {
        header,
        body,
        footer,
        nativeFlowMessage: {
          buttons: nativeFlowButtons,
        },
      },
    }, opts)
  } catch (err) {
    // Fallback ke text
    const fallback = `${body?.text || ''}`
    return await sock.sendMessage(jid, { text: fallback }, opts)
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  EVENT MESSAGE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Kirim event message (undangan event WA)
 * @param {object} eventData
 * @param {string} eventData.name — nama event
 * @param {string} eventData.description — deskripsi event
 * @param {number|string} eventData.startTime — unix timestamp
 * @param {number|string} eventData.endTime — unix timestamp (opsional)
 * @param {object} eventData.location — { degreesLatitude, degreesLongitude, name }
 * @param {string} eventData.joinLink — link join (opsional)
 * @param {boolean} eventData.isCanceled — default false
 * @param {boolean} eventData.extraGuestsAllowed — default true
 */
export async function sendEvent(sock, jid, eventData = {}, options = {}) {
  return await sock.sendMessage(jid, {
    eventMessage: {
      isCanceled: eventData.isCanceled ?? false,
      name: eventData.name || 'Event',
      description: eventData.description || '',
      startTime: String(eventData.startTime || Math.floor(Date.now() / 1000)),
      endTime: eventData.endTime ? String(eventData.endTime) : undefined,
      location: eventData.location || undefined,
      joinLink: eventData.joinLink || undefined,
      extraGuestsAllowed: eventData.extraGuestsAllowed ?? true,
    },
    ...options,
  })
}

// ─────────────────────────────────────────────────────────────────────────────
//  MESSAGE MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────

/** Forward message ke chat lain */
export async function forwardMessage(sock, jid, rawMsg, force = true) {
  return await sock.sendMessage(jid, { forward: rawMsg, force })
}

/** Hapus message (delete for everyone) */
export async function deleteMessage(sock, jid, msgKey) {
  return await sock.sendMessage(jid, { delete: msgKey })
}

/** Edit message yang sudah terkirim */
export async function editMessage(sock, jid, msgKey, newText) {
  return await sock.sendMessage(jid, {
    text: newText,
    edit: msgKey,
  })
}

/**
 * Pin message di chat
 * @param {number} duration — 86400 (24j), 604800 (7h), 2592000 (30h)
 */
export async function pinMessage(sock, jid, msgKey, duration = 86400) {
  return await sock.sendMessage(jid, {
    pin: msgKey,
    type: proto.PinInChat.Type.PIN_FOR_ALL,
    time: duration,
  })
}

/** Unpin message */
export async function unpinMessage(sock, jid, msgKey) {
  return await sock.sendMessage(jid, {
    pin: msgKey,
    type: proto.PinInChat.Type.UNPIN_FOR_ALL,
    time: 0,
  })
}

// ─────────────────────────────────────────────────────────────────────────────
//  PRESENCE / UX
// ─────────────────────────────────────────────────────────────────────────────

/** Kirim pesan dengan efek typing (composing presence) */
export async function sendWithTyping(sock, jid, content, delayMs = 1500) {
  await sock.sendPresenceUpdate('composing', jid)
  await new Promise(r => setTimeout(r, delayMs))
  await sock.sendPresenceUpdate('paused', jid)
  return await sock.sendMessage(jid, content)
}

/** Update presence secara manual */
export async function updatePresence(sock, jid, status = 'available') {
  // status: 'available' | 'unavailable' | 'composing' | 'recording' | 'paused'
  return await sock.sendPresenceUpdate(status, jid)
}

/** Mark message sebagai read */
export async function markAsRead(sock, jid, keys) {
  const keyArray = Array.isArray(keys) ? keys : [keys]
  return await sock.readMessages(keyArray)
}

// ─────────────────────────────────────────────────────────────────────────────
//  NEWSLETTER / CHANNEL
// ─────────────────────────────────────────────────────────────────────────────

/** Follow channel/newsletter */
export async function followChannel(sock, jid) {
  return await sock.newsletterFollow(jid)
}

/** Unfollow channel/newsletter */
export async function unfollowChannel(sock, jid) {
  return await sock.newsletterUnfollow(jid)
}

/** Mute channel/newsletter */
export async function muteChannel(sock, jid, mute = true) {
  return await sock.newsletterMute(jid, mute)
}

/** Kirim reaction ke pesan di channel/newsletter */
export async function sendNewsletterReaction(sock, jid, msgServerID, emoji) {
  try {
    return await sock.newsletterReactMessage(jid, msgServerID, emoji)
  } catch (err) {
    throw new Error(`Gagal react newsletter: ${err.message}`)
  }
}

/**
 * Get metadata newsletter/channel
 * @param {'invite'|'jid'} type
 */
export async function getChannelMetadata(sock, jid, type = 'jid') {
  return await sock.newsletterMetadata(type, jid)
}

// ─────────────────────────────────────────────────────────────────────────────
//  STATUS / STORY
// ─────────────────────────────────────────────────────────────────────────────

/** Kirim text status/story */
export async function sendTextStatus(sock, text, bgColor = '#075E54', font = 0, options = {}) {
  return await sock.sendMessage('status@broadcast', {
    text,
    backgroundArgb: bgColor,
    font,
    ...options,
  })
}

/** Kirim image status/story */
export async function sendImageStatus(sock, source, caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { image: { url: source }, caption }
    : { image: source, caption }
  return await sock.sendMessage('status@broadcast', { ...content, ...options })
}

/** Kirim video status/story */
export async function sendVideoStatus(sock, source, caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { video: { url: source }, caption }
    : { video: source, caption }
  return await sock.sendMessage('status@broadcast', { ...content, ...options })
}

// ─────────────────────────────────────────────────────────────────────────────
//  UTILITY
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Kirim text dengan mention
 * @param {string[]} mentions — ['628xxx@s.whatsapp.net']
 */
export async function sendMention(sock, jid, text, mentions = [], options = {}) {
  return await sock.sendMessage(jid, { text, mentions }, options)
}

/**
 * Reply dengan mention
 */
export async function sendMentionReply(sock, rawMsg, text, mentions = []) {
  return await sock.sendMessage(
    rawMsg.key?.remoteJid || rawMsg.from,
    { text, mentions },
    { quoted: rawMsg }
  )
}

/**
 * Kirim view-once image (hanya bisa dilihat sekali)
 */
export async function sendViewOnceImage(sock, jid, source, caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { image: { url: source }, caption, viewOnce: true }
    : { image: source, caption, viewOnce: true }
  return await sock.sendMessage(jid, { ...content, ...options })
}

/**
 * Kirim view-once video
 */
export async function sendViewOnceVideo(sock, jid, source, caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { video: { url: source }, caption, viewOnce: true }
    : { video: source, caption, viewOnce: true }
  return await sock.sendMessage(jid, { ...content, ...options })
}

/**
 * Kirim GIF dari URL atau Buffer
 */
export async function sendGIF(sock, jid, source, caption = '', options = {}) {
  const content = typeof source === 'string'
    ? { video: { url: source }, caption, gifPlayback: true }
    : { video: source, caption, gifPlayback: true }
  return await sock.sendMessage(jid, { ...content, ...options })
}

/**
 * Request nomor telepon dari user
 */
export async function requestPhoneNumber(sock, jid, options = {}) {
  return await sock.sendMessage(jid, {
    requestPhoneNumberMessage: {},
    ...options,
  })
}

/**
 * Share grup invite ke DM/group
 */
export async function sendGroupInvite(sock, jid, groupJid, inviteCode, groupName, caption = '', options = {}) {
  return await sock.sendMessage(jid, {
    groupInviteMessage: {
      groupJid,
      inviteCode,
      groupName,
      caption,
    },
    ...options,
  })
}

/**
 * Broadcast text ke beberapa JID sekaligus
 * @param {string[]} jids
 */
export async function broadcastText(sock, jids, text, options = {}) {
  const results = []
  for (const jid of jids) {
    try {
      const res = await sock.sendMessage(jid, { text }, options)
      results.push({ jid, success: true, result: res })
    } catch (err) {
      results.push({ jid, success: false, error: err.message })
    }
  }
  return results
}
