import { connectToWhatsApp, disconnectWhatsApp } from './src/connection.js'

connectToWhatsApp().catch(error => {
  console.error('[STARTUP]', error?.message || error)
})

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.once(signal, async () => {
    await disconnectWhatsApp()
    process.exit(0)
  })
}
